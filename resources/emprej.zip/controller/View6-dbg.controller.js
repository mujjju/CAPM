sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/core/UIComponent",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,DataModel) {
        "use strict";

        return Controller.extend("emprej.controller.View6", {
            onInit: function () {
              var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("View6").attachPatternMatched(this._onRouteMatched, this);
              },
              onNavBack : function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("List");
              },
          
              _onRouteMatched: function (oEvent) {
                console.log("Route matched: Start");
                
                var oParameters = oEvent.getParameters();
                var sEmployeeId = oParameters.arguments.SEmployeeId;
                console.log("Employee ID:", sEmployeeId);
            
                var oView = this.getView();
                var oModel = oView.getModel("mainServiceModel"); 
                console.log("oModel:", oModel);
            
                oView.bindElement({
                    path: "/Employees/" + sEmployeeId,
                    model: "mainServiceModel"
                });
                var employeeFirstName = oModel.getProperty("/Employees/" + sEmployeeId + "/fname");
                console.log("Employee First Name:", employeeFirstName);
                console.log("Route matched: End");
            },
          
            });
          });
