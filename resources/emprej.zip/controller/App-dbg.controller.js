sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("emprej.controller.App", {
        onInit() {
        }
      });
    }
  );
  