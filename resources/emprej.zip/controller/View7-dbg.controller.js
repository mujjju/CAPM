sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/ui/core/UIComponent",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/m/StandardListItem",
  ],
  function (
    Controller,
    History,
    UIComponent,
    Filter,
    FilterOperator,
    MessageBox,
    StandardListItem
  ) {
    "use strict";

    return Controller.extend("emprej.controller.View7", {
      onInit: function () {
        this.oList = this.byId("list");

        this.oDataModel = this.getOwnerComponent().getModel();

        this.getView().setModel(this.oDataModel);

        this.showEmployeesFromNetherlands();
        
      },
      showEmployeesFromNetherlands: function () {
        var oFilter = new Filter("country_ID", FilterOperator.EQ, "1");

        this.oList.bindItems({
          path: "/Employees",

          filters: [oFilter],

          template: new StandardListItem({
            title: "{fname} {lname}",

            description: "{desig}",

            icon: "sap-icon://employee",

            iconDensityAware: false,

            iconInset: false,

            press: this.onListItemPressed.bind(this),
          }),
        });
      },
      onListItemPressed: function(oEvent) {
        console.log("Hello");
        var oItem = oEvent.getSource();
        var sPath = oItem.getBindingContext().getPath();
    
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("view6", {
            employeePath: window.encodeURIComponent(sPath)
        });
    },
      //Nav Back start//

      
     
      //Delete Mode end //
    });
  }
);
