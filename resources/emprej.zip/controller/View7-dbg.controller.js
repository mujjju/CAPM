sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/UIComponent"
], function (Controller, UIComponent) {
  "use strict";

  return Controller.extend("emprej.controller.list", {
    onInit: function () {
      this.oTable = this.byId("table0");
      this.oDataModel = this.getOwnerComponent().getModel();
      this.getView().setModel(this.oDataModel);
    },

    onListItemPress: function (oEvent) {
      var oItem = oEvent.getSource();
      var oCtx = oItem.getBindingContext();

      if (oCtx) {
        var sEmployeeId = oCtx.getProperty("ID");
        var oRouter = UIComponent.getRouterFor(this);
        oRouter.navTo("View6", {
          SEmployeeId: sEmployeeId
        });
      } else {
        console.error("Binding context is not available.");
      }
    },

    onSearch: function (oEvent) {
      var sQuery = oEvent.getParameter("query");
      var oBinding = this.oTable.getBinding("items");

      if (sQuery && sQuery.length > 0) {
        var oFilter = new sap.ui.model.Filter("fname", sap.ui.model.FilterOperator.Contains, sQuery);
        oBinding.filter([oFilter]);
      } else {
        oBinding.filter([]);
      }
    },

    onAdd: function () {
      console.log("Add functionality is not ready yet.");
    }
  });
});
