sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/UIComponent",
], function (Controller, UIComponent) {
  "use strict";

  return Controller.extend("emprej.controller.list", {
      onInit: function () {
          this.oDataModel = this.getOwnerComponent().getModel("mainServiceModel");
          this.getView().setModel(this.oDataModel);
      },

      onListItemPress: function(oEvent) {
        var oItem, oCtx;

        oItem = oEvent.getSource();
        oCtx = oItem.getBindingContext("mainServiceModel");

        this.getRouter().navTo("View6",{
            SEmployeeId : oCtx.getProperty("sEmployeeId")
        });

    }
  
     
  });
});
