sap.ui.define(
  ["sap/ui/core/mvc/Controller", "sap/ui/model/odata/v2/ODataModel"],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (Controller, ODataModel) {
    "use strict";

    return Controller.extend("emprej.controller.View1", {
      onInit: function () {
        this.oDataModel = new ODataModel({
          serviceUrl: "/odata/v2",
          defaultBindingMode: sap.ui.model.BindingMode.TwoWay,
        });
      },
      onToPage2: function () {
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("Netherlands");
      },
      onShowIndiaEmployees: function () {
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("India");
      },
      onToPage4: function () {
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("Singapore");
      },
    });
  }
);
